<?php
include 'db.php';

session_start();

function getClientIP() {
    return $_SERVER['REMOTE_ADDR'];
}

function getUserAgent() {
    return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
}

// Get client IP address and user agent
$clientIP = getClientIP();
$userAgent = getUserAgent();

// Rate limiting settings
$rateLimitTime = 60; // seconds
$rateLimitAttempts = 5;

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Check rate limiting based on IP and user-agent
    $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND user_agent = ? AND attempt_time > NOW() - INTERVAL ? SECOND");
    $stmt->bind_param("ssi", $clientIP, $userAgent, $rateLimitTime);
    $stmt->execute();
    $stmt->bind_result($attempts);
    $stmt->fetch();
    $stmt->close();

    if ($attempts >= $rateLimitAttempts) {
        $error_message = "Too many login attempts. Please try again later.";
    } else {
        // Check user credentials
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($userId, $hashedPassword);
        $stmt->fetch();

        if ($stmt->num_rows > 0 && password_verify($password, $hashedPassword)) {
            // Successful login, store user session
            $_SESSION['user_id'] = $userId;

            // Clear login attempts for this IP and user-agent
            $stmt_clear = $conn->prepare("DELETE FROM login_attempts WHERE ip_address = ? AND user_agent = ?");
            $stmt_clear->bind_param("ss", $clientIP, $userAgent);
            $stmt_clear->execute();
            $stmt_clear->close();

            // Redirect to home page
            header("Location: home.php");
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }

        // Log the login attempt
        $stmt = $conn->prepare("INSERT INTO login_attempts (ip_address, user_agent, attempt_time) VALUES (?, ?, NOW())");
        $stmt->bind_param("ss", $clientIP, $userAgent);
        $stmt->execute();
        $stmt->close();
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Login</h1>
    </header>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="signup.php">Signup</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
    </nav>
    <div class="container">
        <form method="POST" action="login.php">
            <?php if (!empty($error_message)) : ?>
                <div class="error-message"><?= $error_message ?></div>
            <?php endif; ?>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>
            <button type="submit">Login</button>
        </form>
    </div>
    <footer>
        <p>&copy; 2024 Our Application</p>
    </footer>
</body>
</html>

