<!DOCTYPE html>
<html>
<head>
    <title>About</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <header>
        <h1>About Us</h1>
    </header>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="signup.php">Signup</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="about-content">
            <h1>About Our Application</h1>
            <p>This is the about page. Here you can include information about your application, the team, or anything relevant to the users.</p>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Our Application</p>
    </footer>
</body>
</html>

