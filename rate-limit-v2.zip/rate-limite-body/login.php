<?php
include 'db.php';

session_start();

function getClientIP() {
    return $_SERVER['REMOTE_ADDR'];
}

$clientIP = getClientIP();
$rateLimitTime = 60; // seconds
$rateLimitAttempts = 5;
$error_message = '';

function parseXMLRequest() {
    $xml = simplexml_load_string(file_get_contents("php://input"));
    $json = json_encode($xml);
    return json_decode($json, TRUE);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';

    if ($contentType === "application/json") {
        $content = trim(file_get_contents("php://input"));
        $decoded = json_decode($content, true);

        $username = $decoded['username'];
        $password = $decoded['password'];
        
        // Check rate limiting
        $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempt_time > NOW() - INTERVAL ? SECOND");
        $stmt->bind_param("si", $clientIP, $rateLimitTime);
        $stmt->execute();
        $stmt->bind_result($attempts);
        $stmt->fetch();
        $stmt->close();

        if ($attempts >= $rateLimitAttempts) {
            $error_message = "Too many login attempts. Please try again later. $clientIP :)";
            $conn->close();
            die($error_message);
        }
    } elseif ($contentType === "application/xml") {
        $decoded = parseXMLRequest();

        $username = $decoded['username'];
        $password = $decoded['password'];
    } else {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempt_time > NOW() - INTERVAL ? SECOND");
        $stmt->bind_param("si", $clientIP, $rateLimitTime);
        $stmt->execute();
        $stmt->bind_result($attempts);
        $stmt->fetch();
        $stmt->close();

        if ($attempts >= $rateLimitAttempts) {
            $error_message = "Too many login attempts. Please try again later. $clientIP :)";
            $conn->close();
            die($error_message);
        }
    }

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($userId, $hashedPassword);
    $stmt->fetch();

    if ($stmt->num_rows > 0 && password_verify($password, $hashedPassword)) {
        $_SESSION['user_id'] = $userId;

        if ($contentType !== "application/xml") {
            $stmt_clear = $conn->prepare("DELETE FROM login_attempts WHERE ip_address = ?");
            $stmt_clear->bind_param("s", $clientIP);
            $stmt_clear->execute();
            $stmt_clear->close();
        }

        header("Location: home.php");
        exit();
    } else {
        $error_message = "Invalid username or password.";
    }

    // Log the attempt (only for JSON and form requests)
    if ($contentType !== "application/xml") {
        $stmt = $conn->prepare("INSERT INTO login_attempts (ip_address, attempt_time) VALUES (?, NOW())");
        $stmt->bind_param("s", $clientIP);
        $stmt->execute();
        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <script>
        function sendLoginRequest(event) {
            event.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            fetch('login.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username: username, password: password })
            })
            .then(response => response.text())
            .then(data => {
                document.open();
                document.write(data);
                document.close();
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</head>
<body>
    <header>
        <h1>Login</h1>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="signup.php">Signup</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
    </nav>
    <div class="container">
        <form onsubmit="sendLoginRequest(event)">
            <?php
            if (!empty($error_message)) {
                echo '<div class="error-message">' . $error_message . '</div>';
            }
            ?>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>
            <button type="submit">Login</button>
        </form>
    </div>
    <footer>
        <p>&copy; 2024 Our Application</p>
    </footer>
</body>
</html>

