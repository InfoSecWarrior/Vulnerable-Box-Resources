<?php
include 'db.php';

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $error_message = "Username already exists. Please choose another one.";
    } else {
        // Insert new user
        $insert_stmt = $conn->prepare("INSERT INTO users (username, password, created_at) VALUES (?, ?, NOW())");
        $insert_stmt->bind_param("ss", $username, $password);
        
        if ($insert_stmt->execute()) {
            $success_message = "Signup successful. You can now <a href='login.php'>login</a>.";
        } else {
            $error_message = "Error: " . $insert_stmt->error;
        }

        $insert_stmt->close();
    }
    
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Signup</h1>
    </header>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
    </nav>
    <div class="container">
        <form method="POST" action="signup.php">
            <?php
            if (!empty($error_message)) {
                echo '<div class="error-message">' . $error_message . '</div>';
            } elseif (!empty($success_message)) {
                echo '<div class="success-message">' . $success_message . '</div>';
            }
            ?>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>
            <button type="submit">Signup</button>
        </form>
    </div>
    <footer>
        <p>&copy; 2024 Our Application</p>
    </footer>
</body>
</html>

