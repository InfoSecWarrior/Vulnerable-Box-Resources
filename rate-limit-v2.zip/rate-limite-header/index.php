<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Welcome to Our Application</h1>
    </header>
    <nav>
        <ul>
            <li><a href="signup.php">Signup</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="home-content">
            <p>Please sign up or login to continue.</p>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Our Application</p>
    </footer>
</body>
</html>

