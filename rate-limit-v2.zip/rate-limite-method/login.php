<?php
include 'db.php';

session_start();

function getClientIP() {
    // Directly return the IP address from $_SERVER['REMOTE_ADDR']
    return $_SERVER['REMOTE_ADDR'];
}

$clientIP = getClientIP();
$rateLimitTime = 60; // seconds
$rateLimitAttempts = 5;
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" || $_SERVER["REQUEST_METHOD"] == "GET") {
    $username = isset($_POST['username']) ? $_POST['username'] : (isset($_GET['username']) ? $_GET['username'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : (isset($_GET['password']) ? $_GET['password'] : '');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check rate limiting for POST requests
        $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND attempt_time > NOW() - INTERVAL ? SECOND");
        $stmt->bind_param("si", $clientIP, $rateLimitTime);
        $stmt->execute();
        $stmt->bind_result($attempts);
        $stmt->fetch();
        $stmt->close();

        if ($attempts >= $rateLimitAttempts) {
            $error_message = "Too many login attempts. Please try again later. $clientIP :)";
        }
    }

    if (empty($error_message)) {
        // Process login
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($userId, $hashedPassword);
        $stmt->fetch();

        if ($stmt->num_rows > 0 && password_verify($password, $hashedPassword)) {
            $_SESSION['user_id'] = $userId;

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Clear login attempts for this IP if POST request
                $stmt_clear = $conn->prepare("DELETE FROM login_attempts WHERE ip_address = ?");
                $stmt_clear->bind_param("s", $clientIP);
                $stmt_clear->execute();
                $stmt_clear->close();
            }
            header("Location: home.php");
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Log the attempt for POST requests
            $stmt = $conn->prepare("INSERT INTO login_attempts (ip_address, attempt_time) VALUES (?, NOW())");
            $stmt->bind_param("s", $clientIP);
            $stmt->execute();
            $stmt->close();
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Login</h1>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="signup.php">Signup</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
    </nav>
    <div class="container">
        <form method="POST" action="login.php">
            <?php
            if (!empty($error_message)) {
                echo '<div class="error-message">' . $error_message . '</div>';
            }
            ?>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>
            <button type="submit">Login</button>
        </form>
    </div>
    <footer>
        <p>&copy; 2024 Our Application</p>
    </footer>
</body>
</html>

