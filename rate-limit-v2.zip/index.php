<?php
session_start();

/*
    METHODS ONLY (NO LEVELS)
*/
$methods = [
    "header" => "rate-limite-header/index.php",
    "body" => "rate-limite-body/index.php",
    "method" => "rate-limite-method/index.php",
    "valid" => "rate-limite-valid/index.php"
];

// GET SELECTED METHOD
$method = isset($_GET['method']) && array_key_exists($_GET['method'], $methods)
    ? $_GET['method']
    : "header";

// Selected file to load
$load_page = $methods[$method];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Rate Limiting Lab</title>
    <style>
        body {
            margin: 0;
            background: #111;
            color: #fff;
            font-family: Arial, sans-serif;
        }

        /* TOP PANEL */
        .top-box {
            background: #222;
            padding: 15px;
            display: flex;
            justify-content: center;
            gap: 20px;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 0 10px black;
        }

        select {
            padding: 10px;
            border-radius: 8px;
            border: none;
            font-size: 16px;
            background: #333;
            color: white;
        }

        iframe {
            width: 100%;
            height: 90vh;
            border: none;
            background: #000;
        }
    </style>

    <script>
        function updatePage() {
            let method = document.getElementById("method").value;
            window.location.href = "index.php?method=" + method;
        }
    </script>
</head>

<body>

<!-- TOP SELECTOR -->
<div class="top-box">

    <!-- METHOD SELECTOR -->
    <select id="method" onchange="updatePage()">
        <option value="header" <?php if($method=="header") echo "selected"; ?>>Header Based</option>
        <option value="body"   <?php if($method=="body") echo "selected"; ?>>Body Based</option>
        <option value="method" <?php if($method=="method") echo "selected"; ?>>Method Based</option>
        <option value="valid"  <?php if($method=="valid") echo "selected"; ?>>Validation Based</option>
    </select>
</div>

<!-- LOAD MODULE INSIDE IFRAME -->
<iframe src="<?php echo $load_page; ?>"></iframe>

</body>
</html>

