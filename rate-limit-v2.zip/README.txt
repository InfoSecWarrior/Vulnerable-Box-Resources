TO Configure Web_Site
 
IMPORT DATABASE 

mysql -u root -p   < db-conf.sql


PLACE FOLDER ON WEB LOCATION 


THANK YOU :) 
